from .Config import Config as MailHideConfig
