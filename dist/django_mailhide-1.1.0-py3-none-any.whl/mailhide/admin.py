"""Mailhide admin registration"""
from django.contrib import admin
from .models import Mailhide


admin.site.register(Mailhide)
