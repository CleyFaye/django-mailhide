from .MailResource import MailResource
